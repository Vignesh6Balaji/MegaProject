let cartItems = [];
let total = 0;
let cartCount = 0;

function setCartCount(count) {
    document.getElementById("cartCount").innerText = count;
}

function addToCart(productName, price) {
    const existingItemIndex = cartItems.findIndex(item => item.name === productName);
    if (existingItemIndex !== -1) {
        cartItems[existingItemIndex].count++;
    } else {
        cartItems.push({ name: productName, price: price, count: 1 });
    }
    total += price;
    updateCart();
}

function removeFromCart(index) {
    const removedItem = cartItems[index];
    if(removedItem.count > 0){
        total -= removedItem.price;
        removedItem.count--;
        if (removedItem.count === 0) {
            cartItems.splice(index, 1);
        }
        updateCart();
    }
}

function removeAllFromCart() {
    cartItems = [];
    total = 0;
    updateCart();
}

function updateCart() {
    const cartItemsElement = document.getElementById('cart-items');
    const cartTotalElement = document.getElementById('cart-total');
    const cartCountElement = document.getElementById('cart-count');

    cartItemsElement.innerHTML='';
    cartCountElement.textContent = cartCount;
    cartItems.forEach((item, index) => {
        const li = document.createElement('li');
        li.textContent = `${item.name} - $${item.price}  x ${item.count}`;
        const removeButton = document.createElement('button');
        removeButton.textContent = 'Remove';
        removeButton.setAttribute('data-index', index);
        removeButton.onclick = () => removeFromCart(index);
        li.appendChild(removeButton);
        cartItemsElement.appendChild(li);
    });
    cartTotalElement.textContent = `Total: $${total.toFixed(2)}`;
    // setCartCount(cartItems.reduce((acc, item) => acc + item.count, 0));
}