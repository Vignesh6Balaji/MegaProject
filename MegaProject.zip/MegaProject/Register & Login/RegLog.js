function register() {
    const username = document.getElementById('register-username').value;
    const password = document.getElementById('register-password').value;
    
    if(username === '' || password === '') {
        alert('Please fill in all fields');
        return;
    }
    
    const user = localStorage.getItem(username);
    if(user) {
    alert('This username already exists');
    return;
    }
    
    localStorage.setItem(username, password);
    document.getElementById('message').innerText = 'Registration successful!';
    alert('Registration successfull!!!');
    if(register){
        document.getElementById('register-username').value = '';
        document.getElementById('register-password').value = '';
        setTimeout(() => { document.getElementById('message').innerText = ''; }, 3000);
    }
    delayedRedirect('RegLog.html', 5000);
}
    
    function login() {
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;
    
    const registeredPassword = localStorage.getItem(username);
    
    if(password === registeredPassword) {
    document.getElementById('message').innerText = 'Login successfull!';
    alert('Login successfull!!!');
    if(login){
        document.getElementById('login-username').value = '';
        document.getElementById('login-password').value = '';
        setTimeout(() => { document.getElementById('message').innerText = ''; }, 3000);
    }
    } else {
    alert('Invalid username or password');
    }
    delayedRedirect('EComm.html', 5000);
    }

    function delayedRedirect(url, delayMillis) {
        setTimeout(function() {
        window.location.href = url;
        }, delayMillis);
        }
        