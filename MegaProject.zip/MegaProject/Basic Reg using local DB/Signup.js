
    function saveData() {
        const name = document.getElementById('username').value;
        localStorage.setItem('username', name);
        const pass = document.getElementById('password').value;
        localStorage.setItem('password', pass);
        displayData();
    }

    function displayData() {
        const name = localStorage.getItem('username');
        document.getElementById('output').innerHTML = `User Name is : ${name}`;
    }

    displayData();